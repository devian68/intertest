window._CCSettings = {
    platform: "ios",
    groupList: [
        "default"
    ],
    collisionMatrix: [
        [
            true
        ]
    ],
    rawAssets: {
        assets: {},
        internal: {
            "14TDKXr2NJ6LjvHPops74o": [
                "effects/builtin-2d-gray-sprite.effect",
                "cc.EffectAsset"
            ],
            "0ek66qC1NOQLjgYmi04HvX": [
                "effects/builtin-2d-spine.effect",
                "cc.EffectAsset"
            ],
            "28dPjdQWxEQIG3VVl1Qm6T": [
                "effects/builtin-2d-sprite.effect",
                "cc.EffectAsset"
            ],
            c0BAyVxX9JzZy8EjFrc9DU: [
                "effects/builtin-clear-stencil.effect",
                "cc.EffectAsset"
            ],
            "796vrvt+9F2Zw/WR3INvx6": [
                "effects/builtin-unlit-transparent.effect",
                "cc.EffectAsset"
            ],
            "6dkeWRTOBGXICfYQ7JUBnG": [
                "effects/builtin-unlit.effect",
                "cc.EffectAsset"
            ],
            "6fgBCSDDdPMInvyNlggls2": [
                "materials/builtin-2d-base.mtl",
                "cc.Material"
            ],
            "3ae7efMv1CLq2ilvUY/tQi": [
                "materials/builtin-2d-gray-sprite.mtl",
                "cc.Material"
            ],
            "7a/QZLET9IDreTiBfRn2PD": [
                "materials/builtin-2d-spine.mtl",
                "cc.Material"
            ],
            "ecpdLyjvZBwrvm+cedCcQy": [
                "materials/builtin-2d-sprite.mtl",
                "cc.Material"
            ],
            cffgu4qBxEqa150o1DmRAy: [
                "materials/builtin-clear-stencil.mtl",
                "cc.Material"
            ],
            "2aKWBXJHxKHLvrBUi2yYZQ": [
                "materials/builtin-unlit.mtl",
                "cc.Material"
            ]
        }
    },
    launchScene: "db://assets/nativeTest.fire",
    scenes: [
        {
            url: "db://assets/nativeTest.fire",
            uuid: "3a4moJrR5Hj61XxGouBYsk"
        }
    ],
    packedAssets: {},
    md5AssetsMap: {},
    orientation: "",
    debug: true,
    subpackages: {}
};
