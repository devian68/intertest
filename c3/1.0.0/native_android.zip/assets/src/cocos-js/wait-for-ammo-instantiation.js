System.register(["./instantiated-6875db35.js"],(function(t){"use strict";return{setters:[function(e){t("default",e.gV)}],execute:function(){}}}));
