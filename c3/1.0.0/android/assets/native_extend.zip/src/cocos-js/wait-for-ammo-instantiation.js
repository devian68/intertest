System.register(["./instantiated-5a3926a8.js"],(function(t){"use strict";return{setters:[function(e){t("default",e.gZ)}],execute:function(){}}}));
